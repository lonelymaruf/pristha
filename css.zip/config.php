<?php

// Database connection

$connect = mysqli_connect("localhost","marufme_maruf","u-os!F;w#NV~","marufme_pristha");

// Website connection

$website_name = "Pristha - পৃষ্ঠা";
$description = "Sell your used books!";
$keywords = "Pristha, sell books dhaka, sell books Bangladesh";
$selltext = "Sell your books";
// Search-engine verification (please paste the values only)

$google = "";
$bing = "";


?>