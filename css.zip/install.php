<?php 
 
// connect to your MySQL db here 
include "config.php";

// Run a check to see if we connected or not 
if (mysqli_connect_errno()) { 
     
    echo "<h2>Sorry, couldn't connect:</h2><em>" . mysqli_connect_error() . "</em>"; 
     
}

 // Create table

$tableCreate = "CREATE TABLE bba (

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult = mysqli_query($connect, $tableCreate); 

 if ($queryResult === TRUE) { 
        print "Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 

 

 // Create table

$tableCreate1 = "CREATE TABLE CSE ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult1 = mysqli_query($connect, $tableCreate1); 

 if ($queryResult1 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 



 // Create table

$tableCreate2 = "CREATE TABLE fiction ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult2 = mysqli_query($connect, $tableCreate2); 

 if ($queryResult2 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 

 

 // Create table

$tableCreate3 = "CREATE TABLE magazine ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult3 = mysqli_query($connect, $tableCreate3); 

 if ($queryResult3 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 



// Create table

$tableCreate4 = "CREATE TABLE medical ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult4 = mysqli_query($connect, $tableCreate4); 

 if ($queryResult4 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 



// Create table

$tableCreate5 = "CREATE TABLE mathematics ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult5 = mysqli_query($connect, $tableCreate5); 

 if ($queryResult5 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 

 
 

// Create table

$tableCreate7 = "CREATE TABLE others ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult7 = mysqli_query($connect, $tableCreate7); 

 if ($queryResult7 === TRUE) { 
        print "<br /><br />Created!"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 

$tableCreate9 = "CREATE TABLE reference ( 

id BIGINT NOT NULL,
title TEXT NOT NULL, 
text TEXT NOT NULL, 
price TEXT NOT NULL,
phone TEXT NOT NULL,
date DATE NOT NULL


)  
    "; 

$queryResult9 = mysqli_query($connect, $tableCreate9); 

 if ($queryResult9 === TRUE) { 
        print "<br /><br />Created! Thank you for installing Damn Simple Classifieds.<br />"; 
    } else { 
        print "<br /><br />No TABLE created. Check"; 
    } 



mysqli_close($connect); 
?>